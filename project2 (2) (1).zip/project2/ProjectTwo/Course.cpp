/*
 * Course.cpp
 *
 *  Created on: Apr 20, 2024
 *      Author: dantenardulli_snhu
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <unordered_map>

using namespace std;

// Course class definition
class Course {
public:
    string number;
    string name;
    vector<string> prerequisites;

    Course(string number, string name, vector<string> prerequisites = {})
        : number(number), name(name), prerequisites(prerequisites) {}
};

// Global vector to store courses
vector<Course> courses;

// Function to open and read file
void openAndReadFile(const string& fileName) {
    ifstream file(fileName);
    if (!file.is_open()) {
        cout << "Error reading file" << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string number, name, prereq;
        vector<string> prerequisites;

        getline(ss, number, ',');
        getline(ss, name, ',');

        while (getline(ss, prereq, ',')) {
            prerequisites.push_back(prereq);
        }

        Course course(number, name, prerequisites);
        courses.push_back(course);
    }

    file.close();
}

// Function to print course list
void printCourseList() {
    sort(courses.begin(), courses.end(), [](const Course& a, const Course& b) {
        return a.number < b.number;
    });

    for (const auto& course : courses) {
        cout << course.number << "," << course.name << endl;
    }
}

// Function to print course information
void printCourse(const string& courseNumber) {
    for (const auto& course : courses) {
        if (course.number == courseNumber) {
            cout << "Course: " << course.number << "," << course.name << endl;
            cout << "Prerequisites: ";
            for (const auto& prereq : course.prerequisites) {
                cout << prereq << " ";
            }
            cout << endl;
            return;
        }
    }
    cout << "Course not found" << endl;
}

// Main menu function
void menu() {
    int choice;
    string fileName;
    string courseNumber;

    do {
        cout << "Menu:" << endl;
        cout << "1. Load Data Structure" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter file name: ";
                cin >> fileName;
                openAndReadFile(fileName);
                break;
            case 2:
                printCourseList();
                break;
            case 3:
                cout << "Enter course number: ";
                cin >> courseNumber;
                printCourse(courseNumber);
                break;
            case 4:
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 4);
}

// Main function
int main() {
    menu();
    return 0;
}

