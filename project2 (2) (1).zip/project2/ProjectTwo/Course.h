/*
 * Course.h
 *
 *  Created on: Apr 20, 2024
 *      Author: dantenardulli_snhu
 */

#ifndef COURSE_H_
#define COURSE_H_

class Course {
public:
	Course();
	virtual ~Course();
};

#endif /* COURSE_H_ */
